function [a] = SP(y,A,x,t)
 alpha = 1; % ���alphaȡ2����CoSaMP�㷨
              r = y; L = []; a_index=[];a_index2=[];
              a = zeros(size(x));
              iter = 1;
              err = 1e-5; % �ź����
              while (iter < 20*t && norm(r)>err)
                     h = A'* r;
                     [h_new,h_index] = sort(abs(h),'descend');
                     L = union(a_index2,h_index(1:alpha*t));
                     a(L) = A(:,L)\y;  
                     [a_new,a_index] = sort(abs(a),'descend');
                     a(a_index(t+1:end))=0; 
                     a_index2 = a_index(1:t);
                     r= y - A*a; % r=y-A(:,a_index2)*pinv(A(:,a_index2))*y;
                     iter = iter + 1;
              end
end

