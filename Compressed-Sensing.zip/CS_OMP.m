function [theta]=CS_OMP(y,A,t)
  [y_rows,y_columns]=size(y);
  if y_rows<y_columns
     y=y';
  end
  [M,N]=size(A);
  theta=zeros(N,1);
  At=zeros(M,t);
  Pos_theta=zeros(1,t);
  r_n=y;
  for ii=1:t
      product=A'*r_n;
      [val,pos]=max(abs(product));
      At(:,ii)=A(:,pos);
      Pos_theta(ii)=pos;
      A(:,pos)=zeros(M,1);
      theta_ls=(At(:,1:ii)'*At(:,1:ii))^(-1)*At(:,1:ii)'*y;
      r_n=y-At(:,1:ii)*theta_ls;
  end
  theta(Pos_theta)=theta_ls;
end
