M=80;N=256;K=15;
Index_K=randperm(N);
x=zeros(N,1);
x(Index_K(1:K))=5*randn(K,1);
Psi=eye(N);
Phi=randn(M,N);
A=Phi*Psi;
y=Phi*x;
theta=CS_OMP(y,A,K);
x_r=Psi*theta;
figure;
plot(x_r,'k.-');
hold on;
plot(x,'r');
hold off;
legend('recovery','original');
fprintf('\�ָ��в�:');
norm(x_r-x)