CNT=1000;N=256;%ϡ��������ֵλ����ͬ������ź��ع��ɹ�����OMP�㷨
Psi=eye(N);
M_set=[52,100,148,196,244];
Percentage=zeros(length(M_set),N);
for  mm=1:length(M_set)
     M=M_set(mm);
     K_set=1:5:ceil(M/2);
     PercentageM=zeros(1,length(K_set));
     for kk=1:length(K_set)
         K=K_set(kk);
         P=0;
         Index_K=randperm(N);
         for cnt=1:CNT
             Index_K=randperm(N);
             x=zeros(N,1);
             x(Index_K(1:K))=5*randn(K,1);
             Phi=randn(M,N);
             A=Phi*Psi;
             y=Phi*x;
             theta=CS_OMP(y,A,K);
             x_r=Psi*theta;
             if norm(x_r-x)<1e-6
                P=P+1;
             end
         end
         PercentageM(kk)=P/CNT*100;
     end
     Percentage(mm,1:length(K_set))=PercentageM;
 end
save KtoPercentage1000test
S=['-bs';'-go';'-rd';'-yv';'-k*'];
figure
for mm=1:length(M_set)
   M=M_set(mm);
   K_set=1:5:ceil(M/2);
   L_Kset=length(K_set);
   plot(K_set,Percentage(mm,1:L_Kset),S(mm,:));
   hold on;
end
hold off;
xlim([0 125]);
legend('M=52','M=100','M=148','M=196','M=244');
xlabel('Sparsity level(K)');
ylabel('Percentage recovered');
title('Percentage of input signals recovered correctly(N=256)');