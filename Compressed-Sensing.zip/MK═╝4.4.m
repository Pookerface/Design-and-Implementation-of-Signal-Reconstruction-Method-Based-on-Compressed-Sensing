CNT=1000;N=256;%������������źŻָ��ɹ����ʵĹ�ϵ��OMP�㷨��
Psi=eye(N);
K_set=[4,12,20,28,36];
Percentage=zeros(length(K_set),N);
for  kk=1:length(K_set)
     K=K_set(kk);
     M_set=K:5:N;
     PercentageK=zeros(1,length(M_set));
     for mm=1:length(M_set)
         M=M_set(mm);
         P=0;
         for cnt=1:CNT
             Index_K=randperm(N);
             x=zeros(N,1);
             x(Index_K(1:K))=5*randn(K,1);
             Phi=randn(M,N);
             A=Phi*Psi;
             y=Phi*x;
             theta=CS_OMP(y,A,K);
             x_r=Psi*theta;
             if norm(x_r-x)<1e-6
                P=P+1;
             end
          end
          PercentageK(mm)=P/CNT*100;
      end
      Percentage(kk,1:length(M_set))=PercentageK;
 end
save MtoPercentage1000
S=['-bs';'-go';'-rd';'-yv';'-k*'];
figure
for kk=1:length(K_set)
   K=K_set(kk);
   M_set=K:5:N;
   L_Mset=length(M_set);
   plot(M_set,Percentage(kk,1:L_Mset),S(kk,:));
   hold on;
end
hold off;
xlim([0 256]);
legend('K=4','K=12','K=20','K=28','K=36');
xlabel('Number of measurements(M)');
ylabel('Percentage recovered');
title('Percentage of input signals recovered correctly(N=256)');